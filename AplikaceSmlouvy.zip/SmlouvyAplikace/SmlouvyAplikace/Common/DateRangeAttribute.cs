﻿using System;
using System.ComponentModel.DataAnnotations;


namespace SmlouvyAplikace.Common
{
    public class DateRangeAttribute : RangeAttribute
    {
        public DateRangeAttribute(string Value) : base(typeof(DateTime), Value, DateTime.Now.ToShortDateString())
        {

        }
    }
}