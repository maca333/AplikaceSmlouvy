﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SmlouvyAplikace.Models;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;

namespace SmlouvyAplikace.Controllers
{
    public class KlientiController : Controller
    {
        private SpravaSmluvDBEntities db = new SpravaSmluvDBEntities();

        // GET: Klienti
        public ActionResult Index()
        {
            return View(db.Klientis.ToList());
        }

        public FileContentResult ExportToCSV()
        {
            var klienti = db.Klientis.ToList();
            StringWriter sw = new StringWriter();
            sw.WriteLine("\"KlientID\",\"Jmeno\",\"Prijmeni\",\"Email\",\"Telefon\",\"Rodne_Cislo\",\"Vek\"");
            foreach (var kli in klienti)
            {
                sw.WriteLine(string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\"",
                     kli.KlientID,
                     kli.Jmeno,
                     kli.Prijmeni,
                     kli.Email,
                     kli.Rodne_Cislo,
                     kli.Jmeno,
                     kli.Vek));
            }
            var fileName = "SeznamKlientu" + DateTime.Now.ToString() + ".csv";
            return File(new System.Text.UTF8Encoding().GetBytes(sw.ToString()), "text/csv", fileName);
        }

        public ActionResult SeraditPrijmeni()
        {
            var klienti = from p in db.Klientis
                          orderby p.Prijmeni ascending
                          select p;
            return View(klienti);
        }

        public JsonResult IsTelefonExist(string Telefon, int? KlientID)
        {
            return Json(!db.Klientis.Any(klient => klient.Telefon == Telefon && klient.KlientID != KlientID), JsonRequestBehavior.AllowGet);
        }

        public JsonResult IsEmailExist(string Email, int? KlientID)
        {
            return Json(!db.Klientis.Any(klient => klient.Email == Email && klient.KlientID != KlientID), JsonRequestBehavior.AllowGet);
        }

        public JsonResult IsRodneCisloExist(string Rodne_Cislo, int? KlientID)
        {
            return Json(!db.Klientis.Any(klient => klient.Rodne_Cislo == Rodne_Cislo && klient.KlientID != KlientID), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Klienti klienti = db.Klientis.Find(id);
            if (klienti == null)
            {
                return HttpNotFound();
            }
            return View(klienti);
        }

        // GET: Klienti/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Klienti/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "KlientID,Jmeno,Prijmeni,Email,Telefon,Rodne_Cislo,Vek")] Klienti klienti)
        {
            if (ModelState.IsValid)
            {
                db.Klientis.Add(klienti);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(klienti);
        }

        // GET: Klienti/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Klienti klienti = db.Klientis.Find(id);
            if (klienti == null)
            {
                return HttpNotFound();
            }
            return View(klienti);
        }

        // POST: Klienti/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "KlientID,Jmeno,Prijmeni,Email,Telefon,Rodne_Cislo,Vek")] Klienti klienti)
        {
            if (ModelState.IsValid)
            {
                db.Entry(klienti).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(klienti);
        }

        // GET: Klienti/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Klienti klienti = db.Klientis.Find(id);
            if (klienti == null)
            {
                return HttpNotFound();
            }
            return View(klienti);
        }

        // POST: Klienti/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Klienti klienti = db.Klientis.Find(id);
            db.Klientis.Remove(klienti);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
