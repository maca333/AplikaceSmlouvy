﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SmlouvyAplikace.Models;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;

namespace SmlouvyAplikace.Controllers
{
    public class PoradciController : Controller
    {
        private SpravaSmluvDBEntities db = new SpravaSmluvDBEntities();

        // GET: Poradci
        public ActionResult Index()
        {
            return View(db.Poradcis.ToList());
        }

        public FileContentResult ExportToCSV()
        {
            var poradci = db.Poradcis.ToList();
            StringWriter sw = new StringWriter();
            sw.WriteLine("\"PoradceID\",\"Jmeno\",\"Prijmeni\",\"Email\",\"Telefon\",\"Rodne_Cislo\",\"Vek\"");
            foreach (var por in poradci)
            {
                sw.WriteLine(string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\"",
                     por.PoradceID,
                     por.Jmeno,
                     por.Prijmeni,
                     por.Email,
                     por.Rodne_Cislo,
                     por.Jmeno,
                     por.Vek));
            }
            var fileName = "SeznamPoradcu" + DateTime.Now.ToString() + ".csv";
            return File(new System.Text.UTF8Encoding().GetBytes(sw.ToString()), "text/csv", fileName);
        }

        public ActionResult SeraditPrijmeni()
        {
            var Poradcis = from p in db.Poradcis
                          orderby p.Prijmeni ascending
                          select p;
            return View(Poradcis);
        }

        public JsonResult IsTelefonExist(string Telefon, int? PoradceID)
        {
            return Json(!db.Poradcis.Any(poradce => poradce.Telefon == Telefon && poradce.PoradceID != PoradceID), JsonRequestBehavior.AllowGet);
        }

        public JsonResult IsEmailExist(string Email, int? PoradceID)
        {
            return Json(!db.Poradcis.Any(poradce => poradce.Email == Email && poradce.PoradceID != PoradceID), JsonRequestBehavior.AllowGet);
        }

        public JsonResult IsRodneCisloExist(string Rodne_Cislo, int? PoradceID)
        {
            return Json(!db.Poradcis.Any(poradce => poradce.Rodne_Cislo == Rodne_Cislo && poradce.PoradceID != PoradceID), JsonRequestBehavior.AllowGet);
        }

        // GET: Poradci/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Poradci poradci = db.Poradcis.Find(id);
            if (poradci == null)
            {
                return HttpNotFound();
            }
            return View(poradci);
        }

        // GET: Poradci/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Poradci/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "PoradceID,Jmeno,Prijmeni,Email,Telefon,Rodne_Cislo,Vek")] Poradci poradci)
        {
            if (ModelState.IsValid)
            {
                db.Poradcis.Add(poradci);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(poradci);
        }

        // GET: Poradci/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Poradci poradci = db.Poradcis.Find(id);
            if (poradci == null)
            {
                return HttpNotFound();
            }
            return View(poradci);
        }

        // POST: Poradci/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "PoradceID,Jmeno,Prijmeni,Email,Telefon,Rodne_Cislo,Vek")] Poradci poradci)
        {
            if (ModelState.IsValid)
            {
                db.Entry(poradci).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(poradci);
        }

        // GET: Poradci/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Poradci poradci = db.Poradcis.Find(id);
            if (poradci == null)
            {
                return HttpNotFound();
            }
            return View(poradci);
        }

        // POST: Poradci/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Poradci poradci = db.Poradcis.Find(id);
            db.Poradcis.Remove(poradci);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
