﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SmlouvyAplikace.Models;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;

namespace SmlouvyAplikace.Controllers
{
    public class SmlouvyController : Controller
    {
        private SpravaSmluvDBEntities db = new SpravaSmluvDBEntities();

        // GET: Smlouvy
        public ActionResult Index()
        {
            var smlouvies = db.Smlouvies.Include(s => s.Klienti).Include(s => s.Poradci);
            return View(smlouvies.ToList());
        }

        public FileContentResult ExportToCSV()
        {
            var smlouvy = db.Smlouvies.ToList();
            StringWriter sw = new StringWriter();
            sw.WriteLine("\"SmlouvaID\",\"KlientID\",\"PoradceID\",\"Evidencni_Cislo\",\"Instituce\",\"Datum_Uzavreni\",\"Datum_Platnosti\",\"Datum_Ukonceni\"");
            foreach (var sml in smlouvy)
            {
                sw.WriteLine(string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\"\"{7}\"",
                     sml.SmlouvaID,
                     sml.KlientID,
                     sml.PoradceID,
                     sml.Evidencni_Cislo,
                     sml.Instituce,
                     sml.Datum_Uzavreni,
                     sml.Datum_Platnosti,
                     sml.Datum_Ukonceni));
            }
            var fileName = "SeznamSmluv" + DateTime.Now.ToString() + ".csv";
            return File(new System.Text.UTF8Encoding().GetBytes(sw.ToString()), "text/csv", fileName);
        }

        public ActionResult SeraditDatumUzavreni()
        {
            var smlouvy = from p in db.Smlouvies
                          orderby p.Datum_Uzavreni ascending
                          select p;
            return View(smlouvy);
        }

        public JsonResult IsEvidencniCisloExist(string Evidencni_Cislo, int? SmlouvaID)
        {
            return Json(!db.Smlouvies.Any(smlouva => smlouva.Evidencni_Cislo == Evidencni_Cislo && smlouva.SmlouvaID != SmlouvaID), JsonRequestBehavior.AllowGet);
        }


        // GET: Smlouvy/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Smlouvy smlouvy = db.Smlouvies.Find(id);
            if (smlouvy == null)
            {
                return HttpNotFound();
            }
            return View(smlouvy);
        }

        // GET: Smlouvy/Create
        public ActionResult Create()
        {
            ViewBag.KlientID = new SelectList(db.Klientis, "KlientID", "CeleJmeno");
            ViewBag.PoradceID = new SelectList(db.Poradcis, "PoradceID", "CeleJmeno");
            return View();
        }

        // POST: Smlouvy/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "SmlouvaID,KlientID,PoradceID,Evidencni_Cislo,Instituce,Datum_Uzavreni,Datum_Platnosti,Datum_Ukonceni")] Smlouvy smlouvy)
        {
            if (ModelState.IsValid)
            {
                db.Smlouvies.Add(smlouvy);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.KlientID = new SelectList(db.Klientis, "KlientID", "CeleJmeno", smlouvy.KlientID);
            ViewBag.PoradceID = new SelectList(db.Poradcis, "PoradceID", "CeleJmeno", smlouvy.PoradceID);
            return View(smlouvy);
        }

        // GET: Smlouvy/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Smlouvy smlouvy = db.Smlouvies.Find(id);
            if (smlouvy == null)
            {
                return HttpNotFound();
            }
            ViewBag.KlientID = new SelectList(db.Klientis, "KlientID", "CeleJmeno", smlouvy.KlientID);
            ViewBag.PoradceID = new SelectList(db.Poradcis, "PoradceID", "CeleJmeno", smlouvy.PoradceID);
            return View(smlouvy);
        }

        // POST: Smlouvy/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "SmlouvaID,KlientID,PoradceID,Evidencni_Cislo,Instituce,Datum_Uzavreni,Datum_Platnosti,Datum_Ukonceni")] Smlouvy smlouvy)
        {
            if (ModelState.IsValid)
            {
                db.Entry(smlouvy).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.KlientID = new SelectList(db.Klientis, "KlientID", "CeleJmeno", smlouvy.KlientID);
            ViewBag.PoradceID = new SelectList(db.Poradcis, "PoradceID", "CeleJmeno", smlouvy.PoradceID);
            return View(smlouvy);
        }

        // GET: Smlouvy/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Smlouvy smlouvy = db.Smlouvies.Find(id);
            if (smlouvy == null)
            {
                return HttpNotFound();
            }
            return View(smlouvy);
        }

        // POST: Smlouvy/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Smlouvy smlouvy = db.Smlouvies.Find(id);
            db.Smlouvies.Remove(smlouvy);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
